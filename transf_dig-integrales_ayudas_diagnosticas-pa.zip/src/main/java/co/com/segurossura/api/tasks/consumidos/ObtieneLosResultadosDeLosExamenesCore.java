package co.com.segurossura.api.tasks.consumidos;

import co.com.segurossura.api.models.request.ResultadoExamenesRequest;
import co.com.segurossura.api.models.response.ResultadoExamenesResponse;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Get;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.util.EnvironmentVariables;

import static co.com.segurossura.api.utils.ConverterFormatoFecha.aplicarFormatoYYYYMMDDaDDMMYYYY;
import static co.com.segurossura.api.utils.ConverterTipoDocumento.convertirTipoDocumentoSuraAEps;
import static co.com.segurossura.api.utils.ObtencionDeVariables.getVariable;
import static co.com.segurossura.api.utils.RecursosEnum.RECURSO_RESULTADO_EXAMENES_CORE;
import static co.com.segurossura.api.utils.TagsEnum.*;
import static io.restassured.http.ContentType.JSON;
import static net.serenitybdd.rest.SerenityRest.lastResponse;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class ObtieneLosResultadosDeLosExamenesCore implements Task {

    private EnvironmentVariables environmentVariables;
    private String documentoUsuario;
    private String numeroUsuario;
    private String fechaInicial;
    private String fechaFinal;
    private String cantidadRegistrosPagina;
    private String pagina;

    public ObtieneLosResultadosDeLosExamenesCore(ResultadoExamenesRequest resultados) {
        this.documentoUsuario = resultados.getDocumentoUsuario();
        this.numeroUsuario = resultados.getNumeroUsuario();
        this.fechaInicial = resultados.getFechaInicial();
        this.fechaFinal = resultados.getFechaFinal();
        this.cantidadRegistrosPagina = resultados.getCantidadRegistrosPagina();
        this.pagina = resultados.getPagina();
    }

    @Step("{0} Obtiene los resultados de los ex�menes desde ayudas diagnosticas")
    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Get.resource(String.format(RECURSO_RESULTADO_EXAMENES_CORE.getAtributo(), numeroUsuario))
                .with(request -> request.contentType(JSON)
                        .urlEncodingEnabled(false)
                        .relaxedHTTPSValidation()
                        .headers(TAG_OCP_APIM_SUBSCRIPTION_KEY.getAtributo(), getVariable(environmentVariables, TAG_OCP_APIM_SUBSCRIPTION_KEY.getAtributo()))
                        .queryParam(TAG_TIPO_IDENTIFICACION.getAtributo(), convertirTipoDocumentoSuraAEps(documentoUsuario))
                        .queryParam(TAG_PAGINA.getAtributo(), pagina)
                        .queryParam(TAG_CANTIDAD_REGISTROS_PAGINA.getAtributo(), cantidadRegistrosPagina)
                        .queryParam(TAG_FECHA_INICIAL.getAtributo(), aplicarFormatoYYYYMMDDaDDMMYYYY(fechaInicial))
                        .queryParam(TAG_FECHA_FINAL.getAtributo(), aplicarFormatoYYYYMMDDaDDMMYYYY(fechaFinal))));


        actor.remember(TAG_ANTERIOR.getAtributo(), lastResponse().jsonPath().getObject("", ResultadoExamenesResponse.class));

    }

    public static ObtieneLosResultadosDeLosExamenesCore desdeAyudasDiagnosticas(ResultadoExamenesRequest resultados) {
        return instrumented(ObtieneLosResultadosDeLosExamenesCore.class, resultados);
    }
}


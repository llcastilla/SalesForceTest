package co.com.segurossura.api.tasks.nuevos;

import co.com.segurossura.api.interactions.ValidaToken;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Get;
import net.thucydides.core.annotations.Step;

import static co.com.segurossura.api.utils.AccionesToken.token;
import static co.com.segurossura.api.utils.RecursosEnum.RECURSO_COMPROBACION;
import static io.restassured.http.ContentType.JSON;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class CompruebaElOhs implements Task {
    @Step("{0} comprueba el estado del ohs")
    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(ValidaToken.paraElServicio(
                Get.resource(RECURSO_COMPROBACION.getAtributo()).with(request ->
                        request.contentType(JSON)
                                .urlEncodingEnabled(false).auth()
                                .oauth2(token()).relaxedHTTPSValidation())));
    }

    public static CompruebaElOhs deAutonomia() {
        return instrumented(CompruebaElOhs.class);
    }
}

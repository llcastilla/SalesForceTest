package co.com.segurossura.api.interfaces;

import co.com.segurossura.api.models.request.CodeModel;

public interface CodeInterface {
    CodeModel build();
}

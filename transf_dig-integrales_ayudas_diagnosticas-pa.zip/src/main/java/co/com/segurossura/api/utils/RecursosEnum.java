package co.com.segurossura.api.utils;

public enum RecursosEnum {
    RUTA_DATA("src/test/resources/Data/DatosPrueba.xlsx"),
    QUERY("Select * from CLAVES where DOCUMENTO='%s'"),
    RECURSO_RESULTADO_EXAMENES_API("/resultado/examen/%s/%s/%s/%s/%s/%s"),
    RECURSO_RESULTADO_EXAMENES_MASIVO_API("/resultado/examenes-masivos"),
    RECURSO_CONSULTA_PDF_API("/resultado/descargar/pdf"),
    RECURSO_MODIFICAR_URL_IMG_API("/resultado/url-imagen"),
    RECURSO_RESULTADO_EXAMENES_CORE("/pacientes/%s"),
    RECUERSO_RESULTADO_EXAMENES_MASIVO_CORE ("/masivos"),
    RECURSO_COMPROBACION("/comprobacion-ohs"),
    RECURSO_SESION_ID("/idp/oauth/authorize"),
    RECURSO_CODE("/idp/oauth/login"),
    RECURSO_TOKEN("/idp/oauth/token");
    private String atributo;

    private RecursosEnum(String atributo) {
        this.atributo = atributo;
    }

    public String getAtributo() {
        return atributo;
    }
}

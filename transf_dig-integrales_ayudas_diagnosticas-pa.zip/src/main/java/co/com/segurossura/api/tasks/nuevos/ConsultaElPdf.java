package co.com.segurossura.api.tasks.nuevos;

import co.com.segurossura.api.interactions.ValidaToken;
import co.com.segurossura.api.models.response.ServicioPdfResponse;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;
import net.thucydides.core.annotations.Step;

import static co.com.segurossura.api.utils.AccionesToken.token;
import static co.com.segurossura.api.utils.RecursosEnum.RECURSO_CONSULTA_PDF_API;
import static io.restassured.http.ContentType.JSON;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class ConsultaElPdf implements Task {

    private ServicioPdfResponse pdf;

    public ConsultaElPdf(ServicioPdfResponse pdf) {
        this.pdf = pdf;
    }

    @Step("{0} consulta el pdf desde una url")
    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(ValidaToken.paraElServicio(
                Post.to(RECURSO_CONSULTA_PDF_API.getAtributo())
                        .with(request -> request.contentType(JSON)
                                .urlEncodingEnabled(false)
                                .relaxedHTTPSValidation()
                                .body(pdf)
                                .auth().preemptive().oauth2(token()))));
    }

    public static ConsultaElPdf deLaUrl(ServicioPdfResponse pdf) {
        return instrumented(ConsultaElPdf.class, pdf);
    }
}


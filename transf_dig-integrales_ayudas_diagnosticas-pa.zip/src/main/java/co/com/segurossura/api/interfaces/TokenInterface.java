package co.com.segurossura.api.interfaces;

import co.com.segurossura.api.models.request.TokenModel;

public interface TokenInterface {
    TokenModel build();
}

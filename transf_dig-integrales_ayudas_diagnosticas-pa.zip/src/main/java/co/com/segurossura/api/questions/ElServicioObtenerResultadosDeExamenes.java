package co.com.segurossura.api.questions;

import co.com.segurossura.api.models.response.ResultadoExamenesResponse;
import com.google.gson.Gson;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import static co.com.segurossura.api.utils.TagsEnum.TAG_ANTERIOR;
import static co.com.segurossura.api.utils.TagsEnum.TAG_JSON;
import static net.serenitybdd.rest.SerenityRest.lastResponse;

public class ElServicioObtenerResultadosDeExamenes implements Question<String> {
    private ElServicioObtenerResultadosDeExamenes() {

    }

    @Override
    public String answeredBy(Actor actor) {
        ResultadoExamenesResponse resultados = actor.recall(TAG_ANTERIOR.getAtributo());
        Serenity.recordReportData().withTitle(TAG_JSON.getAtributo()).andContents(new Gson().toJson(resultados));
        return new Gson().toJson(resultados);
    }

    public static ElServicioObtenerResultadosDeExamenes es() {
        return new ElServicioObtenerResultadosDeExamenes();
    }
}

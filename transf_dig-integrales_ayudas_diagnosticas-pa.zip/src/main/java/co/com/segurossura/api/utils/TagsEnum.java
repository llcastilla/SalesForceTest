package co.com.segurossura.api.utils;

public enum TagsEnum {

    TAG_ENDPOINT_TOKEN("endpoint.token"),
    TAG_ENDPOINT_AYUDAS_DIAGNOSTICAS("endpoint.ayudas"),
    TAG_ENDPOINT_AYUDAS_DIAGNOSTICAS_CONSUMIDO("endpoint.ayudasconsumido"),
    TAG_CLIENT_ID("client_id"),
    TAG_STATE("state"),
    TAG_REDIRECT_URI("redirect_uri"),
    TAG_RESPONSE_TYPE("response_type"),
    TAG_CODE_CHALLENGE("code_challenge"),
    TAG_PASSWORD("password"),
    TAG_TAG("tag"),
    TAG_GRANT_TYPE("grant_type"),
    TAG_SESION_ID("session_id"),
    TAG_CODE_VERIFIER("code_verifier"),
    TAG_JSON("Json consumido"),
    TAG_JSON_API ("Json api"),
    TAG_CODE("code"),
    TAG_ACCESS_TOKEN("access_token"),
    TAG_USUARIO_SEUS("usuarioSeus"),
    TAG_CLAVE_SEUS("claveSeus"),
    TAG_USERNAME("username"),
    TAG_ANTERIOR("anterior"),
    TAG_QUESTION_MENSAJE_RESPUESTA("Verifica el mensaje de respuesta"),
    TAG_CLAVE_EXCEL("CLAVE"),
    TAG_TIPO_DOCUMENTO_EXCEL("TIPODOCUMENTO"),
    TAG_OCP_APIM_SUBSCRIPTION_KEY("Ocp-Apim-Subscription-Key"),
    TAG_OCP_APIM_TRACE("Ocp-Apim-Trace"),
    TAG_TOKEN("token"),
    TAG_TOKEN_PROPERTIES("token.properties"),
    TAG_RUTA_TOKEN_PROPERTIES("./token.properties"),
    TAG_MODIFICACION("Modificaci�n"),
    TAG_MENSAJE("message"),
    TAG_FORMAT_DD_MM_YYYY("MM/dd/yyyy"),
    TAG_FORMAT_YYYY_MM_DD("yyyy-MM-dd"),
    TAG_REGEX_YYYYMMDD_GUION("[0-9]{4}(-)[0-9]{2}(-)[0-9]{2}"),
    TAG_TIPO_IDENTIFICACION("tipoIdentificacion"),
    TAG_PAGINA("pagina"),
    TAG_CANTIDAD_REGISTROS_PAGINA("cantidadRegistrosPagina"),
    TAG_FECHA_INICIAL("fechaInicial"),
    TAG_FECHA_FINAL("fechaFinal"),
    TAG_PDF_BASE_64("pdfBase64"),
    TAG_TYPE("type"),
    TAG_URL_IMG("url"),
    TAG_PETICION("peticion");


    private String atributo;

    private TagsEnum(String atributo) {
        this.atributo = atributo;
    }

    public String getAtributo() {
        return atributo;
    }
}

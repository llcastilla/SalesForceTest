package co.com.segurossura.api.utils;

public enum RespuestaServicioEnum {

    OK(200, "HTTP/1.1 200 OK"),
    PAGE_NO_FOUND(404, "Page Not Found"),
    EXAMENES_NO_FOUND(404, "No se encontraron datos para la entidad ex�menes"),
    PDF_NO_FOUND(404, "No se encontraron datos para la entidad pdf"),
    TECHNICAL(500, "TechnicalException"),
    REGIONAL_NO_FOUND(400, "El campo Regional no puede estar vac�o"),
    ID_USUARIO_NO_FOUND(400, "El campo Id del Usuario no puede estar vac�o"),
    RESULTADOS_NO_FOUND(400, "La lista Resultados Masivos no puede estar vac�a");


    private int codigoRespuesta;
    private String mensajeRespuesta;

    private RespuestaServicioEnum(int codigoRespuesta, String mensajeRespuesta) {
        this.codigoRespuesta = codigoRespuesta;
        this.mensajeRespuesta = mensajeRespuesta;
    }

    public int getCodigoRespuesta() {
        return codigoRespuesta;
    }

    public String getMensajeRespuesta() {
        return mensajeRespuesta;
    }

}

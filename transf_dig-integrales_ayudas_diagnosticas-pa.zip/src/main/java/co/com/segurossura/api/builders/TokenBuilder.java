package co.com.segurossura.api.builders;

import co.com.segurossura.api.interfaces.TokenInterface;
import co.com.segurossura.api.models.request.TokenModel;

public class TokenBuilder implements TokenInterface {
    private String code;
    private String clientId;
    private TokenModel token = new TokenModel();

    public TokenBuilder(String code) {
        this.code = code;
    }

    public static TokenBuilder code(String code) {
        return new TokenBuilder(code);
    }

    public TokenModel clientId(String clientId) {
        this.clientId = clientId;
        return this.build();
    }

    @Override
    public TokenModel build() {
        token.setClientId(this.clientId);
        token.setCode(this.code);
        return token;
    }
}

package co.com.segurossura.api.tasks.nuevos;

import co.com.segurossura.api.builders.CodeBuilder;
import co.com.segurossura.api.builders.TokenBuilder;
import co.com.segurossura.api.interactions.GeneraElCode;
import co.com.segurossura.api.interactions.GeneraElSessionId;
import co.com.segurossura.api.interactions.GeneraElToken;
import co.com.segurossura.api.models.request.CodeModel;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.thucydides.core.annotations.Step;

import static co.com.segurossura.api.utils.AccionesToken.guardarElToken;
import static co.com.segurossura.api.utils.TagsEnum.TAG_ACCESS_TOKEN;
import static co.com.segurossura.api.utils.TagsEnum.TAG_SESION_ID;
import static net.serenitybdd.rest.SerenityRest.lastResponse;

public class CreaTokenGenerico implements Task {
    private String documento;
    private String clave;
    private String clientId;

    public CreaTokenGenerico(CodeModel code) {
        this.documento = code.getDocumento();
        this.clave = code.getClave();
        this.clientId = code.getClientId();
    }

    @Step("{0} genera el token para el usuario #documento")
    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(GeneraElSessionId.conElClientId(clientId));
        actor.attemptsTo(GeneraElCode.conLosDatos(CodeBuilder
                .documento(documento)
                .sessionId(lastResponse().jsonPath().getString(TAG_SESION_ID.getAtributo()))
                .clave(clave)));
        actor.attemptsTo(GeneraElToken.conLosDatos(TokenBuilder
                .code(lastResponse().getBody().asString())
                .clientId(clientId)));
        guardarElToken(lastResponse().jsonPath().getString(TAG_ACCESS_TOKEN.getAtributo()));
    }

    public static CreaTokenGenerico conLosDatos(CodeModel code) {
        return Tasks.instrumented(CreaTokenGenerico.class, code);
    }
}

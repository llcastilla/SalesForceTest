package co.com.segurossura.api.utils;

public class ConverterTipoDocumento {
    private ConverterTipoDocumento() {

    }

    public static String convertirTipoDocumentoSuraAEps(String fuente) {
        String documentoActualizado;
        switch (fuente) {
            case "C":
                documentoActualizado="CC";
                break;
            case "E":
                documentoActualizado= "CE";
                break;
            case "T":
                documentoActualizado="TI";
                break;
            case "D":
                documentoActualizado="CD";
                break;
            case "R":
                documentoActualizado="RC";
                break;
            case "NP":
            case "P":
                documentoActualizado="PA";
                break;
            case "N":
                documentoActualizado="NU";
                break;
            case "TC":
                documentoActualizado="CN";
                break;
            case "TE":
                documentoActualizado="PE";
                break;
            default:
                return fuente;
        }
        return documentoActualizado;
    }
}
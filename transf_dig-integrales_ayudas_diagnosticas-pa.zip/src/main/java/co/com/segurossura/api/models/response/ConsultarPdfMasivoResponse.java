package co.com.segurossura.api.models.response;

public class ConsultarPdfMasivoResponse {

    String pdfbase64;

    public String getPdfbase64() {
        return pdfbase64;
    }

    public void setPdfbase64(String pdfbase64) {
        this.pdfbase64 = pdfbase64;
    }
}

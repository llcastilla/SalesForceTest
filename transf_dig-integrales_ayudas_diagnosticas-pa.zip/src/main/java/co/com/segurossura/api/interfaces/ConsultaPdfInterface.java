package co.com.segurossura.api.interfaces;

import co.com.segurossura.api.models.response.ServicioPdfResponse;

public interface ConsultaPdfInterface {
    ServicioPdfResponse build();
}

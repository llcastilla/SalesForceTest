package co.com.segurossura.api.utils;

import com.testautomationguru.utility.PDFUtil;

import java.io.IOException;

public class LeerPdf {

    public static String leerPdf(String rutaPdf, String archivoPdf) {
        String resultado="";
        PDFUtil pdfUtil = new PDFUtil();
        try {
            resultado = pdfUtil.getText(rutaPdf + archivoPdf);

        } catch (IOException e) {
            e.printStackTrace();
        }
        return resultado;
    }
}

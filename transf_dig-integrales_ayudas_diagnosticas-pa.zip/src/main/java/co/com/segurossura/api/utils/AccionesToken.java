package co.com.segurossura.api.utils;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import static co.com.segurossura.api.utils.TagsEnum.*;

public class AccionesToken {
    private final static Logger LOGGER = Logger.getLogger(AccionesToken.class.getName());

    private AccionesToken() {

    }

    private static Properties prop = new Properties();

    public static void guardarElToken(String token) {

        prop.setProperty(TAG_TOKEN.getAtributo(), token);
        try {
            prop.store(new FileWriter(TAG_TOKEN_PROPERTIES.getAtributo()), TAG_MODIFICACION.getAtributo());
        } catch (IOException e) {
            LOGGER.log(Level.WARNING, e.getMessage());
        }

    }

    public static String token() {
        try {
            InputStream stream = new FileInputStream(TAG_RUTA_TOKEN_PROPERTIES.getAtributo());
            prop.load(stream);
        } catch (IOException e) {
            LOGGER.log(Level.WARNING, e.getMessage());
        }
        return prop.getProperty(TAG_TOKEN.getAtributo());
    }
}

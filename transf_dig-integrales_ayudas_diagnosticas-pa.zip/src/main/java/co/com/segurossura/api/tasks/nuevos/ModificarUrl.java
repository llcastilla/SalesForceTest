package co.com.segurossura.api.tasks.nuevos;

import co.com.segurossura.api.interactions.ValidaToken;
import co.com.segurossura.api.models.response.ServicioPdfResponse;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Put;

import static co.com.segurossura.api.utils.AccionesToken.token;
import static co.com.segurossura.api.utils.RecursosEnum.RECURSO_MODIFICAR_URL_IMG_API;
import static io.restassured.http.ContentType.JSON;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class ModificarUrl implements Task {

    private ServicioPdfResponse img;

    public ModificarUrl(ServicioPdfResponse img) {
        this.img = img;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(ValidaToken.paraElServicio(
                Put.to(RECURSO_MODIFICAR_URL_IMG_API.getAtributo()).with(
                        request -> request.contentType(JSON).urlEncodingEnabled(false)
                                .relaxedHTTPSValidation().body(img)
                                .auth()
                                .preemptive()
                                .oauth2(token()))));
    }


    public static ModificarUrl deImagen(ServicioPdfResponse img) {
        return instrumented(ModificarUrl.class, img);
    }
}

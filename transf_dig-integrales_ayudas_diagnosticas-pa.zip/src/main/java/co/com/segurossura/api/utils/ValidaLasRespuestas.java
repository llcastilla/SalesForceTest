package co.com.segurossura.api.utils;

import static co.com.segurossura.api.utils.TagsEnum.TAG_MENSAJE;
import static co.com.segurossura.api.utils.TagsEnum.TAG_TYPE;
import static net.serenitybdd.rest.SerenityRest.lastResponse;

public class ValidaLasRespuestas {


    private ValidaLasRespuestas() {

    }

    public static String getRespuesta() {

        switch (lastResponse().getStatusCode()) {
            case 200:
            case 201:
            case 204:
            case 405:
                return lastResponse().getStatusLine();
            case 400:
            case 404:
                return lastResponse().jsonPath().getString(TAG_MENSAJE.getAtributo());
            case 500:
                return lastResponse().jsonPath().getString(TAG_TYPE.getAtributo());
            default:
                return null;
        }
    }
}

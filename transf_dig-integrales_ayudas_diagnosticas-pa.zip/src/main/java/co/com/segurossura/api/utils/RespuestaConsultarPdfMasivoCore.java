package co.com.segurossura.api.utils;

import co.com.segurossura.api.models.response.ConsultarPdfMasivoResponse;
import net.serenitybdd.core.Serenity;

import static co.com.segurossura.api.utils.Constantes.*;
import static co.com.segurossura.api.utils.GuardarPdf.convertirAPDF;
import static co.com.segurossura.api.utils.LeerPdf.leerPdf;
import static co.com.segurossura.api.utils.TagsEnum.TAG_JSON;
import static net.serenitybdd.rest.SerenityRest.lastResponse;

public class RespuestaConsultarPdfMasivoCore {

    public static String getRespuestaConsultarPdfMasivoCore()
    {  String resultadoCore="";
        ConsultarPdfMasivoResponse responseCore = lastResponse().getBody().as(ConsultarPdfMasivoResponse.class);
        convertirAPDF(responseCore.getPdfbase64().replaceAll(REGEX, ""), RUTA_PDF, ARCHIVO_CORE_PDF);
        resultadoCore = leerPdf(RUTA_PDF, ARCHIVO_CORE_PDF);
        Serenity.recordReportData().withTitle(TAG_JSON.getAtributo()).andContents(resultadoCore);
        return resultadoCore;
    }
}

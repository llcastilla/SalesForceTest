package co.com.segurossura.api.models.response;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties({ "mostrarSN" })
@JsonPropertyOrder({
        "nombreExamen",
        "fechaServicio",
        "estado",
        "mostrarSN",
        "servicioPDF",
        "sistemaOrigen",
        "formato",
        "regional"

})
public class ExamenesResponse {
    private String nombreExamen;
    private String fechaServicio;
    private String estado;
    private String mostrarSN;
    private ServicioPdfResponse servicioPDF;
    @JsonAlias({"orden", "idOrden"})
    private String orden;
    @JsonAlias({"consecutivo", "idConsecutivo"})
    private String consecutivo;
    private String sistemaOrigen;
    private String formato;
    private String idUsuario;
    private String regional;
    @JsonAlias({"fechaImpresion", "fechaImpresionMur"})
    private String fechaImpresion;

    public String getNombreExamen() {
        return nombreExamen;
    }

    public void setNombreExamen(String nombreExamen) {
        this.nombreExamen = nombreExamen;
    }

    public String getFechaServicio() {
        return fechaServicio;
    }

    public void setFechaServicio(String fechaServicio) {
        this.fechaServicio = fechaServicio;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getMostrarSN() {
        return mostrarSN;
    }

    public void setMostrarSN(String mostrarSN) {
        this.mostrarSN = mostrarSN;
    }

    public ServicioPdfResponse getServicioPDF() {
        return servicioPDF;
    }

    public void setServicioPDF(ServicioPdfResponse servicioPDF) {
        this.servicioPDF = servicioPDF;
    }

    public String getOrden() {
        return orden;
    }

    public void setOrden(String orden) {
        this.orden = orden;
    }

    public String getConsecutivo() {
        return consecutivo;
    }

    public void setConsecutivo(String consecutivo) {
        this.consecutivo = consecutivo;
    }

    public String getSistemaOrigen() {
        return sistemaOrigen;
    }

    public void setSistemaOrigen(String sistemaOrigen) {
        this.sistemaOrigen = sistemaOrigen;
    }

    public String getFormato() {
        return formato;
    }

    public void setFormato(String formato) {
        this.formato = formato;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getRegional() {
        return regional;
    }

    public void setRegional(String regional) {
        this.regional = regional;
    }

    public String getFechaImpresion() {
        return fechaImpresion;
    }

    public void setFechaImpresion(String fechaImpresion) {
        this.fechaImpresion = fechaImpresion;
    }


}

package co.com.segurossura.api.questions;

import co.com.segurossura.api.utils.TagsEnum;
import net.serenitybdd.screenplay.Question;

import static co.com.segurossura.api.utils.ValidaLasRespuestas.getRespuesta;

public class ElMensajeDeError {
    private ElMensajeDeError() {

    }
    public static Question<String> esCorrecto() {
        return Question.about(TagsEnum.TAG_QUESTION_MENSAJE_RESPUESTA.getAtributo()).answeredBy(
                actor -> getRespuesta()
        );
    }
}

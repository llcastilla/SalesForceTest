package co.com.segurossura.api.tasks.nuevos;

import co.com.segurossura.api.interactions.ValidaToken;
import co.com.segurossura.api.models.request.ConsultarPdfMasivoRequest;
import co.com.segurossura.api.models.response.ConsultarPdfMasivoResponse;
import io.restassured.http.ContentType;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.rest.interactions.Post;

import java.util.List;

import static co.com.segurossura.api.utils.AccionesToken.token;
import static co.com.segurossura.api.utils.CrearBodyPdfMasivo.requestBody;
import static co.com.segurossura.api.utils.RecursosEnum.RECURSO_RESULTADO_EXAMENES_MASIVO_API;
import static co.com.segurossura.api.utils.TagsEnum.TAG_ANTERIOR;
import static net.serenitybdd.rest.SerenityRest.lastResponse;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class ConsultarPdfMasivo implements Task {

    private List<ConsultarPdfMasivoRequest> datosRequest;

    public ConsultarPdfMasivo(List<ConsultarPdfMasivoRequest> datosRequest) {
        this.datosRequest = datosRequest;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        OnStage.theActorInTheSpotlight().attemptsTo(
                ValidaToken.paraElServicio(Post.to(String.valueOf(RECURSO_RESULTADO_EXAMENES_MASIVO_API.getAtributo()))
                        .with(request -> request.contentType(ContentType.JSON)
                                .urlEncodingEnabled(false)
                                .relaxedHTTPSValidation()
                                .body(requestBody(datosRequest))
                                .auth().preemptive().oauth2(token()))));


        if (lastResponse().statusCode() == 200) {
            actor.remember(TAG_ANTERIOR.getAtributo(), lastResponse().getBody().as(ConsultarPdfMasivoResponse.class));
        }

    }

    public static ConsultarPdfMasivo desdePortales(List<ConsultarPdfMasivoRequest> datosRequest) {
        return instrumented(ConsultarPdfMasivo.class, datosRequest);
    }
}

package co.com.segurossura.api.tasks.consumidos;

import co.com.segurossura.api.models.request.ConsultarPdfMasivoRequest;
import co.com.segurossura.api.models.response.ConsultarPdfMasivoResponse;
import io.restassured.http.ContentType;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.rest.interactions.Get;
import net.thucydides.core.util.EnvironmentVariables;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

import static co.com.segurossura.api.utils.CrearBodyPdfMasivo.requestBody;
import static co.com.segurossura.api.utils.ObtencionDeVariables.getVariable;
import static co.com.segurossura.api.utils.RecursosEnum.RECUERSO_RESULTADO_EXAMENES_MASIVO_CORE;
import static co.com.segurossura.api.utils.TagsEnum.*;
import static net.serenitybdd.rest.SerenityRest.lastResponse;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class ConsultaPdfMasivoCore implements Task {

    private EnvironmentVariables environmentVariables;
    private List<ConsultarPdfMasivoRequest> datosRequest;

    public ConsultaPdfMasivoCore(List<ConsultarPdfMasivoRequest> datosRequest) {
        this.datosRequest = datosRequest;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {

        byte[] peticion = requestBody(datosRequest).getBytes();
        byte[] p = Base64.getEncoder().encode(peticion);
        String s = new String(p, StandardCharsets.UTF_8);
        OnStage.theActorInTheSpotlight().attemptsTo(
                Get.resource(String.format(RECUERSO_RESULTADO_EXAMENES_MASIVO_CORE.getAtributo()))
                        .with(request -> request.contentType(ContentType.JSON)
                                .header(TAG_OCP_APIM_SUBSCRIPTION_KEY.getAtributo(), getVariable(environmentVariables, TAG_OCP_APIM_SUBSCRIPTION_KEY.getAtributo()))
                                .header(TAG_OCP_APIM_TRACE.getAtributo(), getVariable(environmentVariables, TAG_OCP_APIM_TRACE.getAtributo()))
                                .param(TAG_PETICION.getAtributo(), s)
                                .urlEncodingEnabled(false)
                                .relaxedHTTPSValidation())
        );


    }

    public static ConsultaPdfMasivoCore desdeAyudasDiagnosticas(List<ConsultarPdfMasivoRequest> datosRequest) {
        return instrumented(ConsultaPdfMasivoCore.class, datosRequest);
    }
}

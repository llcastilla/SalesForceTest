package co.com.segurossura.api.utils;

import co.com.segurossura.api.models.request.ConsultarPdfMasivoRequest;

import java.util.List;

import static co.com.segurossura.api.utils.Constantes.BODY_COMPLETO_PDF_MASIVO;
import static co.com.segurossura.api.utils.Constantes.RESULTADOS_PDF_MASIVO;

public class CrearBodyPdfMasivo {


    public static String requestBody(List<ConsultarPdfMasivoRequest> datosRequest) {
        String body = "";
        String resultados = "";
        int i = 0;

        while (i < datosRequest.size()) {
            if (i >= 1) {
                body = body + ",";
            }
            resultados = String.format(RESULTADOS_PDF_MASIVO,
                    datosRequest.get(i).getFechaServicio(),
                    datosRequest.get(i).getNombreExamen(),
                    datosRequest.get(i).getIdUsuario(), datosRequest.get(i).getIdOrden(), datosRequest.get(i).getIdConsecutivo(), datosRequest.get(i).getRegional(), // ->URL
                    datosRequest.get(i).getIdOrden(), datosRequest.get(i).getIdConsecutivo(),
                    datosRequest.get(i).getSistemaOrigen(), datosRequest.get(i).getFormato(),
                    datosRequest.get(i).getRegional(), datosRequest.get(i).getFechaImpresionMur());

            body = body + resultados;

            i = i + 1;
        }

        body = String.format(BODY_COMPLETO_PDF_MASIVO, datosRequest.get(0).getIdUsuario(),
                datosRequest.get(0).getRegional(), body);


        return body;

    }
}

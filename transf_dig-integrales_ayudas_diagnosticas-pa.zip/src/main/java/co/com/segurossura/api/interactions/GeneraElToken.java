package co.com.segurossura.api.interactions;

import static co.com.segurossura.api.utils.Code.convertirCode;
import static co.com.segurossura.api.utils.RecursosEnum.RECURSO_TOKEN;
import static co.com.segurossura.api.utils.TagsEnum.*;
import static co.com.segurossura.api.utils.TokenEnum.*;
import static net.serenitybdd.rest.SerenityRest.lastResponse;

import co.com.segurossura.api.models.request.TokenModel;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.rest.interactions.Post;
import net.thucydides.core.annotations.Step;

public class GeneraElToken implements Interaction {

    private String code;
    private String clientId;

    public GeneraElToken(TokenModel token) {
        this.code = token.getCode();
        this.clientId = token.getClientId();
    }
    @Step("{0} genera el token")
    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Post.to(RECURSO_TOKEN.getAtributo())
                .with(request -> request.urlEncodingEnabled(false)
                        .relaxedHTTPSValidation()
                        .param(TAG_GRANT_TYPE.getAtributo(), GRANT_TYPE.getAtributo())
                        .param(TAG_CODE.getAtributo(), convertirCode(code))
                        .param(TAG_REDIRECT_URI.getAtributo(), REDIRECT_URI.getAtributo())
                        .param(TAG_CLIENT_ID.getAtributo(), clientId)
                        .param(TAG_CODE_VERIFIER.getAtributo(), CODE_VERIFIER.getAtributo())));
        lastResponse().print();
    }

    public static GeneraElToken conLosDatos(TokenModel token) {
        return Tasks.instrumented(GeneraElToken.class, token);
    }
}

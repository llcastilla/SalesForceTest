package co.com.segurossura.api.utils;

public class Code {
	private Code() {

	}

	public static String convertirCode(String code) {
		code = code.split("code=")[1];
		code = code.split("&")[0];
		return code;
	}
}

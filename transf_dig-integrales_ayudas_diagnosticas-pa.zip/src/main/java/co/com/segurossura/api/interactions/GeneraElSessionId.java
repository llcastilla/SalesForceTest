package co.com.segurossura.api.interactions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.rest.interactions.Get;
import net.thucydides.core.annotations.Step;

import static co.com.segurossura.api.utils.RecursosEnum.RECURSO_SESION_ID;
import static co.com.segurossura.api.utils.TagsEnum.*;
import static co.com.segurossura.api.utils.TokenEnum.*;
import static net.serenitybdd.rest.SerenityRest.lastResponse;

public class GeneraElSessionId implements Interaction {
    private String clientId;

    public GeneraElSessionId(String clientId) {
        this.clientId = clientId;
    }

    @Step("{0} genera el sesion id")
    @Override
    public <T extends Actor> void performAs(T actor) {

        actor.attemptsTo(Get.resource(RECURSO_SESION_ID.getAtributo())
                .with(request -> request.relaxedHTTPSValidation().urlEncodingEnabled(false)
                        .queryParam(TAG_CLIENT_ID.getAtributo(), clientId)
                        .queryParam(TAG_STATE.getAtributo(), STATE.getAtributo())
                        .queryParam(TAG_REDIRECT_URI.getAtributo(), REDIRECT_URI.getAtributo())
                        .queryParam(TAG_RESPONSE_TYPE.getAtributo(), RESPONSE_TYPE.getAtributo())
                        .queryParam(TAG_CODE_CHALLENGE.getAtributo(), CODE_CHALLENGE.getAtributo())));
        lastResponse().print();
    }

    public static GeneraElSessionId conElClientId(String clientId) {
        return Tasks.instrumented(GeneraElSessionId.class, clientId);
    }
}

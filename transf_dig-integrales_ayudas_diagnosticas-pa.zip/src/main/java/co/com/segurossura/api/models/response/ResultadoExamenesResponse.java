package co.com.segurossura.api.models.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "examenes", "cantidadPaginas", "totalRegistros" })
public class ResultadoExamenesResponse {
    private List<ExamenesResponse> examenes = null;
    private Integer cantidadPaginas;
    private Integer totalRegistros;

    public List<ExamenesResponse> getExamenes() {
        return examenes;
    }

    public void setExamenes(List<ExamenesResponse> examenes) {
        this.examenes = examenes;
    }

    public Integer getCantidadPaginas() {
        return cantidadPaginas;
    }

    public void setCantidadPaginas(Integer cantidadPaginas) {
        this.cantidadPaginas = cantidadPaginas;
    }

    public Integer getTotalRegistros() {
        return totalRegistros;
    }

    public void setTotalRegistros(Integer totalRegistros) {
        this.totalRegistros = totalRegistros;
    }

    @Override
    public String toString() {
        return "ResultadoExamenesResponse{" +
                "examenes=" + examenes +
                ", cantidadPaginas=" + cantidadPaginas +
                ", totalRegistros=" + totalRegistros +
                '}';
    }
}

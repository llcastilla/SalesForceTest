package co.com.segurossura.api.models.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@JsonInclude(NON_NULL)
@JsonPropertyOrder({"metodo", "url", "urlImgRis"})
public class ServicioPdfResponse {
    private String url;
    private Object urlImgRis;
    private String metodo;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Object getUrlImgRis() {
        return urlImgRis;
    }

    public void setUrlImgRis(Object urlImgRis) {
        this.urlImgRis = urlImgRis;
    }

    public String getMetodo() {
        return metodo;
    }

    public void setMetodo(String metodo) {
        this.metodo = metodo;
    }

    @Override
    public String toString() {
        return "ServicioPdfResponse{" +
                "url='" + url + '\'' +
                ", urlImgRis='" + urlImgRis + '\'' +
                ", metodo='" + metodo + '\'' +
                '}';
    }
}

package co.com.segurossura.api.interfaces;

import co.com.segurossura.api.models.request.ResultadoExamenesRequest;

public interface ResultadoExamenesInterface {
    ResultadoExamenesRequest build();
}

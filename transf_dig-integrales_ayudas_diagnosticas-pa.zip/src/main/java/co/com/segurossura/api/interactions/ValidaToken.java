package co.com.segurossura.api.interactions;

import static co.com.segurossura.api.utils.ObtencionDeVariables.getVariable;
import static co.com.segurossura.api.utils.TagsEnum.TAG_CLAVE_SEUS;
import static co.com.segurossura.api.utils.TagsEnum.TAG_CLIENT_ID;
import static co.com.segurossura.api.utils.TagsEnum.TAG_ENDPOINT_AYUDAS_DIAGNOSTICAS;
import static co.com.segurossura.api.utils.TagsEnum.TAG_ENDPOINT_TOKEN;
import static co.com.segurossura.api.utils.TagsEnum.TAG_USUARIO_SEUS;
import static net.serenitybdd.rest.SerenityRest.lastResponse;

import co.com.segurossura.api.builders.CodeBuilder;
import co.com.segurossura.api.tasks.nuevos.CreaTokenGenerico;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.util.EnvironmentVariables;

public class ValidaToken implements Interaction {
    private EnvironmentVariables environmentVariables;
    private Performable task;

    public ValidaToken(Performable task) {
        this.task = task;
    }

    @Step("Se valida el token")
    @Override
    public <T extends Actor> void performAs(T actor) {
        while (true) {
            actor.attemptsTo(task);
            if (lastResponse().getStatusCode() == 401) {
                actor.whoCan(CallAnApi.at(getVariable(environmentVariables, TAG_ENDPOINT_TOKEN.getAtributo())))
                        .attemptsTo(CreaTokenGenerico.conLosDatos(CodeBuilder
                                .documento(getVariable(environmentVariables, TAG_USUARIO_SEUS.getAtributo()))
                                .clientId(getVariable(environmentVariables, TAG_CLIENT_ID.getAtributo()))
                                .clave(getVariable(environmentVariables, TAG_CLAVE_SEUS.getAtributo()))));
                actor.whoCan(CallAnApi.at(getVariable(environmentVariables, TAG_ENDPOINT_AYUDAS_DIAGNOSTICAS.getAtributo())));
            } else {
                break;
            }
        }
        lastResponse().print();
    }

    public static ValidaToken paraElServicio(Performable task) {
        return Tasks.instrumented(ValidaToken.class, task);
    }
}

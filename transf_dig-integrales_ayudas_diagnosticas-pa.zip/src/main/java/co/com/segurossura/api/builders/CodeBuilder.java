package co.com.segurossura.api.builders;

import co.com.segurossura.api.interfaces.CodeInterface;
import co.com.segurossura.api.models.request.CodeModel;

import static co.com.segurossura.api.utils.LeeElExcel.getTipoDocumento;

public class CodeBuilder implements CodeInterface {
    private String documento;
    private String sessionId;
    private String clave;
    private String clientId;
    private CodeModel code = new CodeModel();

    public CodeBuilder(String documento) {
        this.documento = documento;
    }

    public static CodeBuilder documento(String documento) {
        return new CodeBuilder(documento);
    }

    public CodeBuilder sessionId(String sessionId) {
        this.sessionId = sessionId;
        return this;
    }

    public CodeBuilder clientId(String clientId) {
        this.clientId = clientId;
        return this;
    }

    public CodeModel clave(String clave) {
        this.clave = clave;
        return this.build();
    }

    @Override
    public CodeModel build() {
        code.setClave(this.clave);
        code.setClientId(this.clientId);
        code.setTipoDocumento(getTipoDocumento(this.documento));
        code.setDocumento(this.documento);
        code.setSessionId(this.sessionId);
        return code;
    }
}

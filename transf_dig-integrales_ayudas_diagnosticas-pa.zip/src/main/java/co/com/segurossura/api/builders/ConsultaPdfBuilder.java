package co.com.segurossura.api.builders;

import co.com.segurossura.api.interfaces.ConsultaPdfInterface;
import co.com.segurossura.api.models.response.ServicioPdfResponse;

public class ConsultaPdfBuilder implements ConsultaPdfInterface {
    private String url;
    private ServicioPdfResponse pdf = new ServicioPdfResponse();

    public ConsultaPdfBuilder(String url) {
        this.url = url;
    }

    public static ServicioPdfResponse url(String url) {
        return new ConsultaPdfBuilder(url).build();
    }

    @Override
    public ServicioPdfResponse build() {
        pdf.setUrl(this.url);
        return pdf;
    }
}

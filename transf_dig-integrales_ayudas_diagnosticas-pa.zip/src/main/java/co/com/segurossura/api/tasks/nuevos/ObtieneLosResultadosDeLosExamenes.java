package co.com.segurossura.api.tasks.nuevos;

import co.com.segurossura.api.interactions.ValidaToken;
import co.com.segurossura.api.models.request.ResultadoExamenesRequest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Get;
import net.thucydides.core.annotations.Step;

import static co.com.segurossura.api.utils.AccionesToken.token;
import static co.com.segurossura.api.utils.RecursosEnum.RECURSO_RESULTADO_EXAMENES_API;
import static io.restassured.http.ContentType.JSON;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class ObtieneLosResultadosDeLosExamenes implements Task {

    private String documentoUsuario;
    private String numeroUsuario;
    private String fechaInicial;
    private String fechaFinal;
    private String cantidadRegistros;
    private String pagina;

    public ObtieneLosResultadosDeLosExamenes(ResultadoExamenesRequest resultados) {
        this.documentoUsuario = resultados.getDocumentoUsuario();
        this.numeroUsuario = resultados.getNumeroUsuario();
        this.fechaInicial = resultados.getFechaInicial();
        this.fechaFinal = resultados.getFechaFinal();
        this.cantidadRegistros = resultados.getCantidadRegistrosPagina();
        this.pagina = resultados.getPagina();
    }

    @Step("{0} Obtiene los resultados de los ex�menes desde portales")
    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(ValidaToken.paraElServicio(
                Get.resource(String.format(RECURSO_RESULTADO_EXAMENES_API.getAtributo(), documentoUsuario, numeroUsuario,fechaInicial, fechaFinal, pagina, cantidadRegistros))
                        .with(request -> request.contentType(JSON)
                                .urlEncodingEnabled(false)
                                .relaxedHTTPSValidation()
                                .auth().preemptive().oauth2(token()))));
    }

    public static ObtieneLosResultadosDeLosExamenes desdePortales(ResultadoExamenesRequest resultados) {
        return instrumented(ObtieneLosResultadosDeLosExamenes.class, resultados);
    }
}


package co.com.segurossura.api.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;

import static co.com.segurossura.api.utils.TagsEnum.*;

public class ConverterFormatoFecha {


    private ConverterFormatoFecha() {

    }

    public static String aplicarFormatoYYYYMMDDaDDMMYYYY(String fecha) {
        if (fecha != null && validateFormato(fecha, TAG_REGEX_YYYYMMDD_GUION.getAtributo())) {
            fecha = LocalDate.parse(fecha, DateTimeFormatter.ofPattern(TAG_FORMAT_YYYY_MM_DD.getAtributo()))
                    .format(DateTimeFormatter.ofPattern(TAG_FORMAT_DD_MM_YYYY.getAtributo()));
        }
        return fecha;
    }

    public static boolean validateFormato(String fecha, String formato) {
        return Pattern.compile(formato).matcher(fecha).matches();
    }


}

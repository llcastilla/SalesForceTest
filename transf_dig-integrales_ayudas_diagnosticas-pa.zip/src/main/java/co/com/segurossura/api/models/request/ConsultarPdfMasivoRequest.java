package co.com.segurossura.api.models.request;

public class ConsultarPdfMasivoRequest {

    private String idUsuario;
    private String regional;
    private String nombreExamen;
    private String fechaServicio;
    private String estado;
    private String idOrden;
    private String idConsecutivo;
    private String sistemaOrigen;
    private String formato;
    private String fechaImpresionMur;
    private String url;
    private String metodo;

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getRegional() {
        return regional;
    }

    public void setRegional(String regional) {
        this.regional = regional;
    }

    public String getNombreExamen() {
        return nombreExamen;
    }

    public void setNombreExamen(String nombreExamen) {
        this.nombreExamen = nombreExamen;
    }

    public String getFechaServicio() {
        return fechaServicio;
    }

    public void setFechaServicio(String fechaServicio) {
        this.fechaServicio = fechaServicio;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(String idOrden) {
        this.idOrden = idOrden;
    }

    public String getIdConsecutivo() {
        return idConsecutivo;
    }

    public void setIdConsecutivo(String idConsecutivo) {
        this.idConsecutivo = idConsecutivo;
    }

    public String getSistemaOrigen() {
        return sistemaOrigen;
    }

    public void setSistemaOrigen(String sistemaOrigen) {
        this.sistemaOrigen = sistemaOrigen;
    }

    public String getFormato() {
        return formato;
    }

    public void setFormato(String formato) {
        this.formato = formato;
    }

    public String getFechaImpresionMur() {
        return fechaImpresionMur;
    }

    public void setFechaImpresionMur(String fechaImpresionMur) {
        this.fechaImpresionMur = fechaImpresionMur;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getMetodo() {
        return metodo;
    }

    public void setMetodo(String metodo) {
        this.metodo = metodo;
    }
}

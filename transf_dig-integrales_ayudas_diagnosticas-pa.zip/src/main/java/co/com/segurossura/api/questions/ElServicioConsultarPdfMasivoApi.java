package co.com.segurossura.api.questions;

import co.com.segurossura.api.models.response.ConsultarPdfMasivoResponse;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import static co.com.segurossura.api.utils.Constantes.*;
import static co.com.segurossura.api.utils.GuardarPdf.convertirAPDF;
import static co.com.segurossura.api.utils.LeerPdf.leerPdf;
import static co.com.segurossura.api.utils.TagsEnum.TAG_ANTERIOR;
import static co.com.segurossura.api.utils.TagsEnum.TAG_JSON_API;

public class ElServicioConsultarPdfMasivoApi implements Question<String> {
    @Override
    public String answeredBy(Actor actor) {
        ConsultarPdfMasivoResponse response = actor.recall(TAG_ANTERIOR.getAtributo());
        convertirAPDF(response.getPdfbase64().replaceAll(REGEX, ""), RUTA_PDF, ARCHIVO_API_PDF);
        String resultado = leerPdf(RUTA_PDF, ARCHIVO_API_PDF);
        Serenity.recordReportData().withTitle(TAG_JSON_API.getAtributo()).andContents(resultado);
        return resultado;
    }

    public static ElServicioConsultarPdfMasivoApi es() {
        return new ElServicioConsultarPdfMasivoApi();
    }
}

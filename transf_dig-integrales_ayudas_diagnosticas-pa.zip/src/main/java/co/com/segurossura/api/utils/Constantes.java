package co.com.segurossura.api.utils;

public class Constantes {
    public static final String RESULTADOS_PDF_MASIVO = "  {\n" +
            "         \"estado\":\"Finalizado\",\n" +
            "         \"fechaServicio\":\"%s\",\n" +
            "         \"nombreExamen\":\"%s\",\n" +
            "         \"servicioPDF\":{\n" +
            "            \"metodo\":\"GET\",\n" +
            "            \"url\":\"https://adxsura-lab.azure-api.net/adx/v1/pacientes/%s/%s/pdf?consecutivo=%s&regional=%s\"\n" +
            "         },\n" +
            "         \"idOrden\":\"%s\",\n" +
            "         \"idConsecutivo\":\"%s\",\n" +
            "         \"sistemaOrigen\":\"%s\",\n" +
            "         \"formato\":\"%s\",\n" +
            "         \"regional\":\"%s\",\n" +
            "         \"fechaImpresionMur\":\"%s\"\n" +
            "      }";

    public static final String BODY_COMPLETO_PDF_MASIVO = "{\n" +
            "   \"idUsuario\":\"%s\",\n" +
            "   \"regional\":\"%s\",\n" +
            "   \"resultados\":[\n" +
            "      %s   \n" +
            "   ]\n" +
            "}";
    public static final String DATA = "dataRequest";
    public static final String REGEX = "\r\n";
    public static final String RUTA_PDF = "src/test/resources/Data/examenes Masivos Pdf/";
    public static final String ARCHIVO_CORE_PDF = "examen_core_pdf";
    public static final String ARCHIVO_API_PDF = "examen_api_pdf";

}

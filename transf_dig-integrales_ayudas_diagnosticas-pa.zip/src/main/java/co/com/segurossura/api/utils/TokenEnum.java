package co.com.segurossura.api.utils;

public enum TokenEnum {
    STATE("AppsegurosSura"),
    REDIRECT_URI("sura://appsegurossura"),
    RESPONSE_TYPE("code"),
    TAG("PORTALES"),
    CODE_CHALLENGE("qjrzSW9gMiUgpUvqgEPE4_-8swvyCtfOVvg55o5S_es"),
    GRANT_TYPE("authorization_code"),
    CODE_VERIFIER("M25iVXpKU3puUjFaYWg3T1NDTDQtcW1ROUY5YXlwalNoc0hhakxifmZHag");
    private String atributo;

    private TokenEnum(String atributo) {
        this.atributo = atributo;
    }

    public String getAtributo() {
        return atributo;
    }
}

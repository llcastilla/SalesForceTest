package co.com.segurossura.api.exceptions;

@SuppressWarnings("serial")
public class Exceptions extends AssertionError{
    public static final String CODIGO_RESPUESTA = "EL CODIGO DE RESPUESTA NO ES IGUAL";
    public static final String MENSAJE_DE_ERROR = "EL MENSAJE DE ERROR ES DIFERENTE";
    public static final String COMPARACION_DE_SERVICIOS = "LAS RESPUESTAS DE LOS SERVICIOS SON DIFERENTES";
    public Exceptions(String message, Throwable cause) {
        super(message, cause);

    }
}

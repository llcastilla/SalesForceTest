package co.com.segurossura.api.builders;

import co.com.segurossura.api.interfaces.ResultadoExamenesInterface;
import co.com.segurossura.api.models.request.ResultadoExamenesRequest;

public class ResultadoExamenesBuilder implements ResultadoExamenesInterface {
    private String tipoIdentificacion;
    private String numeroIdentificacion;
    private String documentoUsuario;
    private String numeroUsuario;
    private String fechaInicial;
    private String fechaFinal;
    private String cantidadRegistrosPagina;
    private String pagina;
    private ResultadoExamenesRequest resultado = new ResultadoExamenesRequest();

    public ResultadoExamenesBuilder(String fechaInicial) {
        this.fechaInicial = fechaInicial;
    }


    public static ResultadoExamenesBuilder fechaInicial(String fechaInicial) {
        return new ResultadoExamenesBuilder(fechaInicial);
    }

    public ResultadoExamenesBuilder tipoIdentificacion(String tipoIdentificacion) {
        this.tipoIdentificacion = tipoIdentificacion;
        return this;
    }

    public ResultadoExamenesBuilder numeroUsuario(String numeroUsuario) {
        this.numeroUsuario = numeroUsuario;
        return this;
    }

    public ResultadoExamenesBuilder documentoUsuario(String documentoUsuario) {
        this.documentoUsuario = documentoUsuario;
        return this;
    }

    public ResultadoExamenesBuilder fechaFinal(String fechaFinal) {
        this.fechaFinal = fechaFinal;
        return this;
    }

    public ResultadoExamenesBuilder numeroIdentificacion(String numeroIdentificacion) {
        this.numeroIdentificacion = numeroIdentificacion;
        return this;
    }

    public ResultadoExamenesBuilder cantidadRegistrosPagina(String cantidadRegistrosPagina) {
        this.cantidadRegistrosPagina = cantidadRegistrosPagina;
        return this;
    }

    public ResultadoExamenesRequest pagina(String pagina) {
        this.pagina = pagina;
        return this.build();
    }


    @Override
    public ResultadoExamenesRequest build() {
        resultado.setFechaFinal(this.fechaFinal);
        resultado.setCantidadRegistrosPagina(this.cantidadRegistrosPagina);
        resultado.setPagina(this.pagina);
        resultado.setNumeroIdentificacion(this.numeroIdentificacion);
        resultado.setTipoIdentificacion(this.tipoIdentificacion);
        resultado.setDocumentoUsuario(this.documentoUsuario);
        resultado.setNumeroUsuario(this.numeroUsuario);
        resultado.setFechaInicial(this.fechaInicial);


        return resultado;
    }
}

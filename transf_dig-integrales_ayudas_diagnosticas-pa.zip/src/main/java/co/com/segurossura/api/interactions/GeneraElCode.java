package co.com.segurossura.api.interactions;

import static co.com.segurossura.api.utils.RecursosEnum.RECURSO_CODE;
import static co.com.segurossura.api.utils.TagsEnum.TAG_PASSWORD;
import static co.com.segurossura.api.utils.TagsEnum.TAG_SESION_ID;
import static co.com.segurossura.api.utils.TagsEnum.TAG_TAG;
import static co.com.segurossura.api.utils.TagsEnum.TAG_USERNAME;
import static co.com.segurossura.api.utils.TokenEnum.TAG;
import static net.serenitybdd.rest.SerenityRest.lastResponse;

import co.com.segurossura.api.models.request.CodeModel;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.rest.interactions.Post;
import net.thucydides.core.annotations.Step;

public class GeneraElCode implements Interaction {
    private String sessionId;
    private String documento;
    private String clave;
    private String tipoDocumento;

    public GeneraElCode(CodeModel code) {
        this.sessionId = code.getSessionId();
        this.documento = code.getDocumento();
        this.clave = code.getClave();
        this.tipoDocumento = code.getTipoDocumento();
    }

    @Step("{0} genera el code para el documento #documento")
    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Post.to(RECURSO_CODE.getAtributo())
                .with(request -> request
                        .urlEncodingEnabled(false)
                        .relaxedHTTPSValidation()
                        .param(TAG_SESION_ID.getAtributo(), sessionId)
                        .param(TAG_USERNAME.getAtributo(), tipoDocumento + documento)
                        .param(TAG_PASSWORD.getAtributo(), clave)
                        .param(TAG_TAG.getAtributo(), TAG.getAtributo())));
        lastResponse().print();
    }

    public static GeneraElCode conLosDatos(CodeModel code) {
        return Tasks.instrumented(GeneraElCode.class, code);
    }
}

package co.com.segurossura.api.utils;

import sun.misc.BASE64Decoder;

import java.io.File;
import java.io.FileOutputStream;

public class GuardarPdf {

    public static String convertirAPDF(String base64Doc, String srcDest, String fileDest) {
        BASE64Decoder decoder = new BASE64Decoder();
        String filePath = "";
        try {
            byte[] decodeBytes = decoder.decodeBuffer(base64Doc);
            new File(srcDest).mkdir();
            filePath = srcDest + fileDest;
            File file = new File(filePath);
            FileOutputStream fop = new FileOutputStream(file);
            fop.write(decodeBytes);
            fop.flush();
            fop.close();

        } catch (Exception e) {
            System.out.println("Error al convertir pdf");
        }
        return filePath;
    }
}


package co.com.segurossura.api.utils;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

import java.util.logging.Level;
import java.util.logging.Logger;

import static co.com.segurossura.api.utils.RecursosEnum.QUERY;
import static co.com.segurossura.api.utils.RecursosEnum.RUTA_DATA;
import static co.com.segurossura.api.utils.TagsEnum.TAG_CLAVE_EXCEL;
import static co.com.segurossura.api.utils.TagsEnum.TAG_TIPO_DOCUMENTO_EXCEL;

public class LeeElExcel {
    private static String clave;
    private static String tipoDocumento;
    private static Fillo fillo = new Fillo();
    private static Connection connection;
    private final static Logger LOGGER = Logger.getLogger(LeeElExcel.class.getName());

    private LeeElExcel() {

    }

    public static String getClave(String documento) {
        try {
            connection = fillo.getConnection(RUTA_DATA.getAtributo());
            Recordset recordset = connection.executeQuery(String.format(QUERY.getAtributo(), documento));
            while (recordset.next()) {
                clave = recordset.getField(TAG_CLAVE_EXCEL.getAtributo());
            }
            recordset.close();
            connection.close();
        } catch (FilloException e) {
            LOGGER.log(Level.WARNING, e.getMessage());
        }
        return clave;
    }
    public static String getTipoDocumento(String documento) {
        try {
            connection = fillo.getConnection(RUTA_DATA.getAtributo());
            Recordset recordset = connection.executeQuery(String.format(QUERY.getAtributo(), documento));
            while (recordset.next()) {
                tipoDocumento = recordset.getField(TAG_TIPO_DOCUMENTO_EXCEL.getAtributo());
            }
            recordset.close();
            connection.close();
        } catch (FilloException e) {
            LOGGER.log(Level.WARNING, e.getMessage());
        }
        return tipoDocumento;
    }
}

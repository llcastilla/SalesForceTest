package co.com.segurossura.api.stepsdefinitions.examenes;

import co.com.segurossura.api.exceptions.Exceptions;
import co.com.segurossura.api.models.request.ConsultarPdfMasivoRequest;
import co.com.segurossura.api.questions.ElServicioConsultarPdfMasivoApi;
import co.com.segurossura.api.tasks.consumidos.ConsultaPdfMasivoCore;
import co.com.segurossura.api.tasks.nuevos.ConsultarPdfMasivo;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;

import java.util.List;

import static co.com.segurossura.api.exceptions.Exceptions.CODIGO_RESPUESTA;
import static co.com.segurossura.api.exceptions.Exceptions.COMPARACION_DE_SERVICIOS;
import static co.com.segurossura.api.utils.Constantes.DATA;
import static co.com.segurossura.api.utils.ObtencionDeVariables.getVariable;
import static co.com.segurossura.api.utils.RespuestaConsultarPdfMasivoCore.getRespuestaConsultarPdfMasivoCore;
import static co.com.segurossura.api.utils.RespuestaServicioEnum.valueOf;
import static co.com.segurossura.api.utils.TagsEnum.TAG_ENDPOINT_AYUDAS_DIAGNOSTICAS;
import static co.com.segurossura.api.utils.TagsEnum.TAG_ENDPOINT_AYUDAS_DIAGNOSTICAS_CONSUMIDO;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static net.serenitybdd.screenplay.rest.questions.ResponseConsequence.seeThatResponse;
import static org.hamcrest.Matchers.equalTo;

public class ConsultarPdfMasivoStepDefinition {


    private EnvironmentVariables environmentVariables;

    @Dado("se tengan los datos que debe retornar el servicio masivo")
    public void seTenganLosDatosQueDebeRetornarElServicioMasivo(List<ConsultarPdfMasivoRequest> datosRequest) {

        theActorInTheSpotlight().
                whoCan(CallAnApi.at(getVariable(environmentVariables, TAG_ENDPOINT_AYUDAS_DIAGNOSTICAS.getAtributo())))
                .attemptsTo(ConsultarPdfMasivo.desdePortales(datosRequest));

        OnStage.theActorInTheSpotlight().remember(DATA, datosRequest);

    }

    @Cuando("el usuario consulte varios resultados de sus ex�menes")
    public void elUsuarioConsulteVariosResultadosDeSusEx�menes() {

        List<ConsultarPdfMasivoRequest> datos = OnStage.theActorInTheSpotlight().recall(DATA);
        theActorInTheSpotlight().whoCan(CallAnApi.at(getVariable(environmentVariables, TAG_ENDPOINT_AYUDAS_DIAGNOSTICAS_CONSUMIDO.getAtributo())))
                .attemptsTo(ConsultaPdfMasivoCore.desdeAyudasDiagnosticas(datos));

    }

    @Entonces("el usuario ver� un pdf con varios resultados {string}")
    public void elUsuarioVer�UnPdfConVariosResultadosRespuesta(String respuesta) {
        theActorInTheSpotlight()
                .should(seeThatResponse(response -> response.statusCode(valueOf(respuesta).getCodigoRespuesta()))
                                .orComplainWith(Exceptions.class, CODIGO_RESPUESTA),
                        seeThat(ElServicioConsultarPdfMasivoApi.es(),
                                equalTo(getRespuestaConsultarPdfMasivoCore()))
                                .orComplainWith(Exceptions.class, COMPARACION_DE_SERVICIOS));
    }


}

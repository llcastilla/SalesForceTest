package co.com.segurossura.api.stepsdefinitions.examenes;

import co.com.segurossura.api.builders.ResultadoExamenesBuilder;
import co.com.segurossura.api.exceptions.Exceptions;
import co.com.segurossura.api.models.request.ResultadoExamenesRequest;
import co.com.segurossura.api.models.response.ResultadoExamenesResponse;
import co.com.segurossura.api.questions.ElMensajeDeError;
import co.com.segurossura.api.questions.ElServicioObtenerResultadosDeExamenes;
import co.com.segurossura.api.tasks.consumidos.ObtieneLosResultadosDeLosExamenesCore;
import co.com.segurossura.api.tasks.nuevos.ObtieneLosResultadosDeLosExamenes;
import com.google.gson.Gson;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;

import java.util.List;

import static co.com.segurossura.api.exceptions.Exceptions.*;
import static co.com.segurossura.api.utils.ObtencionDeVariables.getVariable;
import static co.com.segurossura.api.utils.RespuestaServicioEnum.valueOf;
import static co.com.segurossura.api.utils.TagsEnum.TAG_ENDPOINT_AYUDAS_DIAGNOSTICAS;
import static co.com.segurossura.api.utils.TagsEnum.TAG_ENDPOINT_AYUDAS_DIAGNOSTICAS_CONSUMIDO;
import static net.serenitybdd.rest.SerenityRest.lastResponse;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static net.serenitybdd.screenplay.rest.questions.ResponseConsequence.seeThatResponse;
import static org.hamcrest.Matchers.equalTo;

public class ResultadoDeExamenesStepDefinition {
    private EnvironmentVariables environmentVariables;

    @Dado("se tengan los datos que debe retornar el servicio")
    public void seTenganLosDatosQueDebeRetornarElServicio(List<ResultadoExamenesRequest> resultados) {
        theActorInTheSpotlight().whoCan(CallAnApi.at(getVariable(environmentVariables, TAG_ENDPOINT_AYUDAS_DIAGNOSTICAS_CONSUMIDO.getAtributo())))
                .attemptsTo(ObtieneLosResultadosDeLosExamenesCore.desdeAyudasDiagnosticas(
                        ResultadoExamenesBuilder
                                .fechaInicial(resultados.get(0).getFechaInicial())
                                .documentoUsuario(resultados.get(0).getDocumentoUsuario())
                                .numeroUsuario(resultados.get(0).getNumeroUsuario())
                                .cantidadRegistrosPagina(resultados.get(0).getCantidadRegistrosPagina())
                                .fechaFinal(resultados.get(0).getFechaFinal())
                                .pagina(resultados.get(0).getPagina())));
    }

    @Cuando("el usuario consulte los resultados de sus ex�menes")
    public void elUsuarioConsulteLosResultadosDeSusEx�menes(List<ResultadoExamenesRequest> resultados) {
        theActorInTheSpotlight().whoCan(CallAnApi.at(getVariable(environmentVariables, TAG_ENDPOINT_AYUDAS_DIAGNOSTICAS.getAtributo())))
                .attemptsTo(ObtieneLosResultadosDeLosExamenes.desdePortales(
                        ResultadoExamenesBuilder
                                .fechaInicial(resultados.get(0).getFechaInicial())
                                .documentoUsuario(resultados.get(0).getDocumentoUsuario())
                                .numeroUsuario(resultados.get(0).getNumeroUsuario())
                                .cantidadRegistrosPagina(resultados.get(0).getCantidadRegistrosPagina())
                                .fechaFinal(resultados.get(0).getFechaFinal())
                                .pagina(resultados.get(0).getPagina())));
    }

    @Entonces("el usuario ver� los sus resultados {string}")
    public void elUsuarioVer�LosSusResultados(String respuesta) {
        theActorInTheSpotlight()
                .should(seeThatResponse(response -> response.statusCode(valueOf(respuesta).getCodigoRespuesta()))
                                .orComplainWith(Exceptions.class, CODIGO_RESPUESTA),
                        seeThat(ElServicioObtenerResultadosDeExamenes.es(),
                                equalTo(new Gson().toJson(lastResponse().getBody().as(ResultadoExamenesResponse.class))))
                                .orComplainWith(Exceptions.class, COMPARACION_DE_SERVICIOS));

    }

    @Entonces("el usuario ver� el mensaje de error {string}")
    public void elUsuarioVer�ElMensajeDeError(String respuesta) {
        theActorInTheSpotlight()
                .should(seeThatResponse(response -> response.statusCode(valueOf(respuesta).getCodigoRespuesta()))
                                .orComplainWith(Exceptions.class, CODIGO_RESPUESTA),
                        seeThat(ElMensajeDeError.esCorrecto(), equalTo(valueOf(respuesta).getMensajeRespuesta()))
                                .orComplainWith(Exceptions.class, MENSAJE_DE_ERROR));

    }

}

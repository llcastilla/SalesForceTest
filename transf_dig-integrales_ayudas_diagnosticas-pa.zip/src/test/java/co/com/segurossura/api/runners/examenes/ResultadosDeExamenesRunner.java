package co.com.segurossura.api.runners.examenes;

import io.cucumber.junit.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

import static io.cucumber.junit.CucumberOptions.SnippetType.CAMELCASE;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features = "src/test/resources/features/examenes/resultado_examenes.feature"
        , glue = "co/com/segurossura/api/stepsdefinitions"
        , snippets = CAMELCASE)
public class ResultadosDeExamenesRunner {
}

package co.com.segurossura.api.runners.examenes;

import io.cucumber.junit.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        features = "src/test/resources/features/examenes/consultar_pdf_masivo.feature",
        glue = "co/com/segurossura/api/stepsdefinitions",
        snippets = CucumberOptions.SnippetType.CAMELCASE
)
public class ConsultarPdfMasivoRunner {
}

package co.com.segurossura.api.stepsdefinitions.hooks;


import co.com.segurossura.api.tasks.nuevos.CreaTokenGenerico;
import io.cucumber.java.Before;
import io.cucumber.java.es.Dado;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;

import static co.com.segurossura.api.builders.CodeBuilder.documento;
import static co.com.segurossura.api.utils.LeeElExcel.getClave;
import static co.com.segurossura.api.utils.ObtencionDeVariables.getVariable;
import static co.com.segurossura.api.utils.TagsEnum.*;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;

public class Hooks {

    private EnvironmentVariables environmentVariables;


    @Before
    public void setTheStage() {
        OnStage.setTheStage(new OnlineCast());
        OnStage.aNewActor();
    }

    @Dado("que el usuario consume el servicio de portales")
    public void queElUsuarioConsumeElServicioDePortales() {
        theActorInTheSpotlight().whoCan(CallAnApi.at(getVariable(environmentVariables, TAG_ENDPOINT_AYUDAS_DIAGNOSTICAS.getAtributo())));
    }

    @Dado("que el usuario ingrese su documento {string}")
    public void queElUsuarioIngreseSuDocumento(String documento) {
        theActorInTheSpotlight().whoCan(CallAnApi.at(getVariable(environmentVariables, TAG_ENDPOINT_TOKEN.getAtributo())))
                .attemptsTo(CreaTokenGenerico.conLosDatos(documento(documento)
                        .clientId(getVariable(environmentVariables, TAG_CLIENT_ID.getAtributo()))
                        .clave(getClave(documento))));
    }
}

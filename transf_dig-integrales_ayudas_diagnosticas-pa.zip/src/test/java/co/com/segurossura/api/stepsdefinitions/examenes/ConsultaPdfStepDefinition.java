package co.com.segurossura.api.stepsdefinitions.examenes;

import co.com.segurossura.api.tasks.nuevos.ConsultaElPdf;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Entonces;

import static co.com.segurossura.api.builders.ConsultaPdfBuilder.url;
import static co.com.segurossura.api.utils.RespuestaServicioEnum.valueOf;
import static co.com.segurossura.api.utils.TagsEnum.TAG_PDF_BASE_64;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static net.serenitybdd.screenplay.rest.questions.ResponseConsequence.seeThatResponse;
import static org.hamcrest.Matchers.*;

public class ConsultaPdfStepDefinition {
    @Cuando("el usuario ingrese la url {string}")
    public void elUsuarioIngreseLaUrl(String url) {
        theActorInTheSpotlight().attemptsTo(ConsultaElPdf.deLaUrl(url(url)));
    }

    @Entonces("el usuario ver� el pdf {string}")
    public void elUsuarioVer�ElPdf(String respuesta) {
        theActorInTheSpotlight()
                .should(seeThatResponse(response -> response
                        .statusCode(valueOf(respuesta).getCodigoRespuesta())
                        .body(TAG_PDF_BASE_64.getAtributo(), is(not(emptyString())))));

    }
}

package co.com.segurossura.api.stepsdefinitions.examenes;


import co.com.segurossura.api.tasks.nuevos.ModificarUrl;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Entonces;

import static co.com.segurossura.api.builders.ConsultaPdfBuilder.url;
import static co.com.segurossura.api.utils.RespuestaServicioEnum.valueOf;
import static co.com.segurossura.api.utils.TagsEnum.TAG_URL_IMG;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static net.serenitybdd.screenplay.rest.questions.ResponseConsequence.seeThatResponse;
import static org.hamcrest.Matchers.*;

public class ModificarUrlImagenStepDefinition {

    @Cuando("el usuario ingrese la url de la imagen {string}")
    public void elUsuarioIngreseLaUrlDeLaImagen(String url) {
        theActorInTheSpotlight().attemptsTo(ModificarUrl.deImagen(url(url)));
    }

    @Entonces("el usuario ver� la url de la imagen {string}")
    public void elUsuarioVer�LaUrlDeLaImagen(String respuesta) {
        theActorInTheSpotlight().should(seeThatResponse(response -> response
                .statusCode(valueOf(respuesta).getCodigoRespuesta())
                .body(TAG_URL_IMG.getAtributo(), is(not(emptyString())))));
    }

}

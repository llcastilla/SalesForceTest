package co.com.segurossura.api.stepsdefinitions.comprobacion;

import co.com.segurossura.api.exceptions.Exceptions;
import co.com.segurossura.api.tasks.nuevos.CompruebaElOhs;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Entonces;

import static co.com.segurossura.api.exceptions.Exceptions.CODIGO_RESPUESTA;
import static co.com.segurossura.api.utils.RespuestaServicioEnum.valueOf;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static net.serenitybdd.screenplay.rest.questions.ResponseConsequence.seeThatResponse;

public class ComprobacionOhsStepDefinition {

    @Cuando("el usuario revise el estado del ohs")
    public void elUsuarioReviseElEstadoDelOhs() {
        theActorInTheSpotlight().attemptsTo(CompruebaElOhs.deAutonomia());
    }

    @Entonces("el usuario ver� el ohs {string}")
    public void elUsuarioVer�ElOhs(String respuesta) {
        theActorInTheSpotlight().should(seeThatResponse(response ->
                response.statusCode(valueOf(respuesta).getCodigoRespuesta()))
                .orComplainWith(Exceptions.class, CODIGO_RESPUESTA));
    }
}

package co.com.segurossura.api.runners.comprobacion;

import io.cucumber.junit.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

import static io.cucumber.junit.CucumberOptions.SnippetType.CAMELCASE;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features = "src/test/resources/features/comprobacion/comprobacion_ohs.feature"
        , glue = "co/com/segurossura/api/stepsdefinitions"
        , snippets = CAMELCASE)
public class ComprobacionOhsRunner {
}
